function init () {

	source = {
		102 : "30.54319381713867;50.463733042004385;102",
		101 : "30.56447982788086;50.41453422654013;101",
		103 : "30.43830871582031;50.467557473306535;103",
		110 : "30.50830871582031;50.467557473306535;110"
	};
	function sourceToCsv (source) {
		return _.values(source).join("\n");
	}

	var lastInsertedId = 105;

	map.init({
		initial : {
			zoomLevel : 11,
			focus : {
				lon : 30.50430719999997,
				lat : 50.42285039999999
			},
		},
		container : document.getElementById("map"),
		source : sourceToCsv(source),
		choosingLocationModeDone : function () {
			jQuery("#create-point-mode").removeClass("pressed-button");
			jQuery("#create-point-controls").hide();
		},
		moveMarkerModeDone : function () {
			jQuery("#move-point-mode").removeClass("pressed-button");
			jQuery("#move-point-controls").hide();
			jQuery("#move-point-mode .selected-point-id").text("");
		},
		locationPicked : function (point) {
			if (map.isInChoosingLocationMode())
				jQuery("#create-point-controls .selected-point").text(point.lon + ";" + point.lat);
			if (map.isInMoveMarkerMode())
				jQuery("#move-point-controls .selected-point").text(point.lon + ";" + point.lat);
		},
		popupOpened : function (options) {
			popup = jQuery("#popup-form");
			popup.find(".id").text(options.id)
			popup.appendTo(options.container);
		},
		popupClosing : function (options) {
			jQuery("#popup-form").appendTo("#popup-holder");
		},
		markerSelected : function (options) {
			jQuery("#move-point-mode .selected-point-id, #remove-point .selected-point-id").text(options.id)
		},
		markerDeselected : function (options) {
			if (!map.isInMoveMarkerMode())
				jQuery("#move-point-mode .selected-point-id").text("")
			jQuery("#remove-point .selected-point-id").text("")
		},
		moveMarkerModeEntered : function () {
			map.closePopup();
		}
	});

	jQuery("#create-point-mode").click(function () {
		if (!jQuery("#create-point-mode").hasClass("pressed-button")) {
			map.choosingLocationMode();
			jQuery("#create-point-controls .selected-point").text("");
			jQuery("#create-point-controls").show();
			jQuery("#create-point-mode").addClass("pressed-button");
		}
	});

	jQuery("#create-point").click(function () {
		var point = jQuery("#create-point-controls .selected-point").text();
		if (point != "") {
			var id = lastInsertedId++;
			source[id] = point + ";" + id;
			map.options.source = sourceToCsv(source);
			map.stopChoosingLocationMode();
			map.loadMarkers();
		} else {
			map.warning("no point selected");
		}
	});

	jQuery("#stop-create-point-mode").click(function () {
		map.stopChoosingLocationMode();
	});

	jQuery("#move-point-mode").click(function () {
		var id = jQuery("#move-point-mode .selected-point-id").text();
		if (!jQuery("#move-point-mode").hasClass("pressed-button") && id != "") {
			map.moveMarkerMode(id);
			jQuery("#move-point-controls .selected-point").text("");
			jQuery("#move-point-controls").show();
			jQuery("#move-point-mode").addClass("pressed-button");
		}
	});

	jQuery("#move-point").click(function () {
		var point = jQuery("#move-point-controls .selected-point").text();
		if (point != "") {
			var id = jQuery("#move-point-mode .selected-point-id").text();
			//map.moveMarker(jQuery("#move-point-mode .selected-point-id").text(), map.pickedLocation());
			source[id] = point + ";" + id;
			map.options.source = sourceToCsv(source);
			map.stopMoveMarkerMode();
			map.loadMarkers();
		} else {
			map.warning("no point selected");
		}
	});

	jQuery("#stop-move-point-mode").click(function () {
		map.stopMoveMarkerMode();
	});

	jQuery("#remove-point").click(function () {
		var id = jQuery("#remove-point .selected-point-id").text();
		if (id != "") {
			if (confirm("Remove " + id + "?")) {
				//map.removeMarker(id);
				map.deselectMarkers();
				delete(source[id]);
				map.options.source = sourceToCsv(source);
				map.loadMarkers();
			}
		}
	});
}

