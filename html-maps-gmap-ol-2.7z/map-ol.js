window.map = {

	selectControl : null,
	map : null,
	markersLayer : null,
	markers : null,

	_pickedLocation : null,

	warning : function () {
		console.log.apply(null, arguments);
	},

	modes : {
		NONE : null,
		PICK_LOCATION : 'pick-location',
		CHANGE_LOCATION : 'change-location'
	},
	clickActionMode : null,

	loadMarkers : function (source) {
		var markersData = this.options.source.split("\n");
		var _this = this;
		this.markersLayer.removeAllFeatures();
		_.each(markersData, function (markerLine) {
			var markerData = markerLine.split(";");
			var point = new OpenLayers.Geometry.Point(markerData[0], markerData[1]);
			point.transform("EPSG:4326", _this.map.getProjectionObject());
			var marker = new OpenLayers.Feature.Vector(point, {id : markerData[2]});
			_this.markers[marker.attributes.id] = marker;
			_this.markersLayer.addFeatures(marker);
		});
	},

	selectMarker : function (markerId) {
		this.selectControl.unselectAll();
		this.selectControl.select(this.markers[markerId]);
	},

	deselectMarkers : function () {
		this.selectControl.unselectAll();
	},

	closePopup : function () {
		this.deselectMarkers();
	},

	/*
	moveMarker : function (id, location) {
		//var point = new OpenLayers.Geometry.Point(location[0], location[1]);
		var point = new OpenLayers.LonLat(location);
		point.transform("EPSG:4326", this.map.getProjectionObject());
		this.markers[id].move(point);
	},

	removeMarker : function (id) {
		this.deselectMarkers();
		this.markersLayer.removeFeatures(this.markers[id]);
	},
	*/

	choosingLocationMode : function () {
		if (!this.isInChoosingLocationMode()) {
			this.clickActionMode = this.modes.PICK_LOCATION;
			if (this.options.chooseLocationModeEntered)
				this.options.chooseLocationModeEntered();
		} else {
			this.warning("choosingLocationMode: already in choosingLocationMode");
		}
	},

	isInChoosingLocationMode : function () {
		return this.clickActionMode == this.modes.PICK_LOCATION;
	},

	stopChoosingLocationMode : function () {
		if (this.isInChoosingLocationMode()) {
			this.clickActionMode = this.modes.NONE;
			if (this.options.choosingLocationModeDone)
				this.options.choosingLocationModeDone();
		} else {
			this.warning("stopChoosingLocationMode: stopping while not in choosingLocationMode");
		}
	},

	pickedLocation : function () {
		return this._pickedLocation;
	},

	moveMarkerMode : function (markerId) {
		if (!this.isInMoveMarkerMode()) {
			this.clickActionMode = this.modes.CHANGE_LOCATION;
			if (this.options.moveMarkerModeEntered)
				this.options.moveMarkerModeEntered();
		} else {
			this.warning("moveMarkerMode: already in moveMarkerMode");
		}
	},

	isInMoveMarkerMode : function () {
		return this.clickActionMode == this.modes.CHANGE_LOCATION;
	},

	stopMoveMarkerMode : function () {
		if (this.isInMoveMarkerMode()) {
			this.clickActionMode = this.modes.NONE;
			if (this.options.moveMarkerModeDone)
				this.options.moveMarkerModeDone();
		} else {
			this.warning("stopMoveMarkerMode: stopping while not in moveMarkerMode");
		}
	},

	isInViewMode : function () {
		return this.clickActionMode == this.modes.NONE;
	},

	returnToViewMode : function () {
		if (this.isInMoveMarkerMode()) {
			this.stopMoveMarkerMode()
		}
		if (this.isInChoosingLocationMode()) {
			this.stopChoosingLocationMode()
		}
	},

	init : function (options) {
		var _this = this;
		this.options = options;
		this.markers = {};

		this.map = new OpenLayers.Map({div: options.container, allOverlays: true, projection: "EPSG:3857"});

		var osm = new OpenLayers.Layer.OSM(null, null, {visibility: false});
		var gmap = new OpenLayers.Layer.Google("Google Streets");
		this.markersLayer = new OpenLayers.Layer.Vector("Markers", {
			strategies: [new OpenLayers.Strategy.BBOX({resFactor: 1.1})],
			protocol: new OpenLayers.Protocol.HTTP()
			//{url: "txt", format: new OpenLayers.Format.Text()})
		});
		//var local = new OpenLayers.Layer.WMS("OpenLayers WMS", "http://localhost:8091/", {layers: "osm", format:'image/png'});

		this.map.addLayers([this.markersLayer]);
		//this.map.addLayers([local]);
		this.map.addLayers([gmap]);
		this.map.addLayers([osm]);

		this.map.addControl(new OpenLayers.Control.LayerSwitcher());
		//this.map.zoomToMaxExtent();

		this.focusPoint = new OpenLayers.LonLat(options.initial.focus.lon, options.initial.focus.lat).transform(
			new OpenLayers.Projection("EPSG:4326"),
			this.map.getProjectionObject()
		);
		this.map.setCenter(this.focusPoint, options.initial.zoomLevel);

		this.selectControl = new OpenLayers.Control.SelectFeature(this.markersLayer);
		this.map.addControl(this.selectControl);
		this.selectControl.activate();

		this.markersLayer.events.on({
			'featureselected': this.onFeatureSelect.bind(this),
			'featureunselected': this.onFeatureUnselect.bind(this)
		});
		//map.addControl(new OpenLayers.Control.EditingToolbar(this.markersLayer));

		this.map.events.register("click", this.map, function (event) {
			//console.log(1, event.xy)
			if (_this.isInChoosingLocationMode() || _this.isInMoveMarkerMode()) {
				var point = _this.map.getLonLatFromViewPortPx(event.xy);
				point.transform(_this.map.getProjectionObject(), "EPSG:4326");
				_this._pickedLocation = {lon : point.lon, lat : point.lat};
				if (_this.options.locationPicked)
					_this.options.locationPicked(_this._pickedLocation);
			}
		});

		this.loadMarkers();
	},

	onPopupClose : function (evt) {
		//console.log(evt, this);
		// 'this' is the popup.
		var feature = this.feature;
		if (feature.layer) { // The feature is not destroyed
			this.selectControl.unselect(feature);
		} else { // After "moveend" or "refresh" events on POIs layer all
			//     features have been destroyed by the Strategy.BBOX
			this.destroy();
		}
	},

	onFeatureSelect : function (event) {
		//console.log(event.feature.data.title, arguments)
		var feature = event.feature;
		if (this.options.markerSelected) {
			this.options.markerSelected({
				id : feature.attributes.id,
				feature : feature
			});
		}
		var popup = new OpenLayers.Popup.FramedCloud("featurePopup",
			feature.geometry.getBounds().getCenterLonLat(),
			new OpenLayers.Size(100,100),
			"<div></div>",
			null,
			true,
			this.onPopupClose
		);
		popup.selectControl = this.selectControl;
		feature.popup = popup;
		popup.feature = feature;
		this.map.addPopup(popup, true);
		if (this.options.popupOpened) {
			this.options.popupOpened({
				container : popup.contentDiv,
				id : feature.attributes.id,
				feature : feature,
				popup : popup
			});
			popup.updateSize();
		}
	},

	onFeatureUnselect : function (event) {
		//console.log(event.feature.data.title, arguments)
		var feature = event.feature;
		if (this.options.popupClosing) {
			this.options.popupClosing({
				container : feature.popup.contentDiv,
				id : feature.attributes.id,
				feature : feature,
				popup : feature.popup
			})
		}
		if (feature.popup) {
			feature.popup.feature = null;
			this.map.removePopup(feature.popup);
			feature.popup.destroy();
			feature.popup = null;
		}
		if (this.options.markerDeselected) {
			this.options.markerDeselected({
				id : feature.attributes.id,
				feature : feature
			});
		}
	},

};

