var map = {

	markers : null,
	map : null,
	selectedMarkerId : null,

	_pickedLocation : null,

	warning : function () {
		console.log.apply(null, arguments);
	},

	modes : {
		NONE : null,
		PICK_LOCATION : 'pick-location',
		CHANGE_LOCATION : 'change-location'
	},
	clickActionMode : null,

	loadMarkers : function (source) {
		var markersData = this.options.source.split("\n");
		var _this = this;
		_.each(this.markers, function (marker) {
			marker.setMap(null);
		});
		this.markers = {};
		_.each(markersData, function (markerLine) {
			var markerData = markerLine.split(";");
			var point = new google.maps.LatLng(markerData[1], markerData[0]);
			var marker= new google.maps.Marker({
				position : point,
				map : _this.map,
				storedId : markerData[2]
			});
			google.maps.event.addListener(marker, 'click', function (event) {
				_this.selectMarker(marker.storedId);
			});
			_this.markers[markerData[2]] = marker;
		});
	},

	selectMarker : function (markerId) {
		console.log("select marker");
		var _this = this;
		if (this.selectedMarkerId != markerId) {
			this.deselectMarkers()
		}
		var marker = this.markers[markerId];
		this.selectedMarkerId = markerId;
		if (this.options.markerSelected) {
			this.options.markerSelected({
				id : markerId,
				marker : marker
			});
		}
		var infoWindow = new google.maps.InfoWindow({content: document.createElement("div")});
		infoWindow.open(this.map, marker);
		google.maps.event.addListener(infoWindow, 'closeclick', function () {
			console.log("popup closing");
			if (_this.options.popupClosing) {
				_this.options.popupClosing({
					container : infoWindow.getContent(),
					id : markerId,
					infoWindow : infoWindow
				})
			}
			_this.selectedMarkerId = null;
			if (_this.options.markerDeselected) {
				_this.options.markerDeselected({
					id : markerId
				})
			}
		});
		marker.infoWindow = infoWindow;
		if (this.options.popupOpened) {
			this.options.popupOpened({
				container : infoWindow.getContent(),
				id : markerId,
				marker : marker,
				infoWindow : infoWindow
			});
		}
	},

	deselectMarkers : function () {
		console.log("deselect marker");
		this.closePopup();
	},

	closePopup : function () {
		console.log("close popup");
		if (this.selectedMarkerId && this.markers[this.selectedMarkerId].infoWindow) {
			this.markers[this.selectedMarkerId].infoWindow.close();
		}
	},

	choosingLocationMode : function () {
		if (!this.isInChoosingLocationMode()) {
			this.clickActionMode = this.modes.PICK_LOCATION;
			if (this.options.chooseLocationModeEntered)
				this.options.chooseLocationModeEntered();
		} else {
			this.warning("choosingLocationMode: already in choosingLocationMode");
		}
	},

	isInChoosingLocationMode : function () {
		return this.clickActionMode == this.modes.PICK_LOCATION;
	},

	stopChoosingLocationMode : function () {
		if (this.isInChoosingLocationMode()) {
			this.clickActionMode = this.modes.NONE;
			if (this.options.choosingLocationModeDone)
				this.options.choosingLocationModeDone();
		} else {
			this.warning("stopChoosingLocationMode: stopping while not in choosingLocationMode");
		}
	},

	pickedLocation : function () {
		return this._pickedLocation;
	},

	moveMarkerMode : function (markerId) {
		if (!this.isInMoveMarkerMode()) {
			this.clickActionMode = this.modes.CHANGE_LOCATION;
			if (this.options.moveMarkerModeEntered)
				this.options.moveMarkerModeEntered();
		} else {
			this.warning("moveMarkerMode: already in moveMarkerMode");
		}
	},

	isInMoveMarkerMode : function () {
		return this.clickActionMode == this.modes.CHANGE_LOCATION;
	},

	stopMoveMarkerMode : function () {
		if (this.isInMoveMarkerMode()) {
			this.clickActionMode = this.modes.NONE;
			if (this.options.moveMarkerModeDone)
				this.options.moveMarkerModeDone();
		} else {
			this.warning("stopMoveMarkerMode: stopping while not in moveMarkerMode");
		}
	},

	isInViewMode : function () {
		return this.clickActionMode == this.modes.NONE;
	},

	returnToViewMode : function () {
		if (this.isInMoveMarkerMode()) {
			this.stopMoveMarkerMode()
		}
		if (this.isInChoosingLocationMode()) {
			this.stopChoosingLocationMode()
		}
	},

	init : function (options) {
		var _this = this;
		this.options = options;
		this.markers = {};

		this.loadMarkers();

		var mapOptions = {
			center : new google.maps.LatLng(options.initial.focus.lat, options.initial.focus.lon),
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			zoomControl : true,
			zoomControlOptions : {
				style: google.maps.ZoomControlStyle.LARGE,
				position: google.maps.ControlPosition.TOP_LEFT
			},
			mapTypeControl : true,
			mapTypeControlOptions : {
				style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
				position: google.maps.ControlPosition.TOP_RIGHT
			},
			scaleControl : true,
			scaleControlOptions : {
				position: google.maps.ControlPosition.TOP_LEFT
			},
			streetViewControl : false,
			panControl : false, zoom : options.initial.zoomLevel
		};
		this.map = new google.maps.Map(options.container, mapOptions);

		google.maps.event.addListener(this.map, 'click', function(event) {
			console.log(event);
			if (_this.isInChoosingLocationMode() || _this.isInMoveMarkerMode()) {
				_this._pickedLocation = {lon : event.latLng.lng(), lat : event.latLng.lat()};
				if (_this.options.locationPicked)
					_this.options.locationPicked(_this._pickedLocation);
			}
		});

		this.loadMarkers();
	},

};
